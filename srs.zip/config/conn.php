<?php
$conn = mysqli_connect("localhost", "root", "", "srp");
if (!$conn) die("Database connection failed");
