<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | SRS Electrical Appliances</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Base Styles and Reset - EXACTLY SAME AS OTHER PAGES */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary-blue: #1a5f7a;
            --accent-blue: #2a86ba;
            --light-blue: #57c5e6;
            --dark-gray: #333;
            --medium-gray: #666;
            --light-gray: #f8f9fa;
            --white: #ffffff;
            --border-color: #e0e0e0;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
            --success-green: #28a745;
            --danger-red: #dc3545;
        }

        body {
            line-height: 1.6;
            color: var(--dark-gray);
            background-color: var(--light-gray);
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 40px 0;
        }

        /* Navbar Styles - EXACTLY SAME AS OTHER PAGES */
        header {
            background-color: var(--white);
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logo-icon {
            color: var(--primary-blue);
            font-size: 2rem;
            margin-right: 10px;
        }

        .logo-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-blue);
        }

        .nav-menu {
            display: flex;
            list-style: none;
        }

        .nav-menu li {
            position: relative;
            margin-left: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: var(--dark-gray);
            font-weight: 600;
            transition: var(--transition);
            padding: 5px 0;
            position: relative;
        }

        .nav-menu a:hover {
            color: var(--primary-blue);
        }

        .nav-menu a.active {
            color: var(--primary-blue);
        }

        .nav-menu a.active:after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            background: var(--primary-blue);
            left: 0;
            bottom: 0;
        }

        .nav-menu a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary-blue);
            left: 0;
            bottom: 0;
            transition: var(--transition);
        }

        .nav-menu a:hover:after {
            width: 100%;
        }

        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: var(--white);
            min-width: 200px;
            box-shadow: var(--shadow);
            border-radius: 4px;
            z-index: 1;
            top: 100%;
            left: 0;
            padding: 10px 0;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a {
            display: block;
            padding: 10px 20px;
            color: var(--dark-gray);
        }

        .dropdown-content a:hover {
            background-color: var(--light-gray);
        }

        .dashboard-btn {
            background-color: var(--accent-blue);
            color: white;
            padding: 10px 25px;
            border-radius: 4px;
        }

        .dashboard-btn:hover {
            background-color: var(--primary-blue);
            transform: translateY(-3px);
        }

        .mobile-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary-blue);
        }

        /* Page Header - EXACTLY SAME AS OTHER PAGES */
        .page-header {
            background-color: var(--white);
            padding: 30px 0;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 30px;
            position: relative;
            top: auto;
             z-index: 900;
        }

        .page-title {
            font-size: 2.5rem;
            color: var(--primary-blue);
            font-weight: 700;
            text-align: center;
        }

        .page-subtitle {
            text-align: center;
            color: var(--medium-gray);
            margin-top: 10px;
            font-size: 1.1rem;
        }

        /* Section Titles - EXACTLY SAME AS OTHER PAGES */
        .section-title {
            font-size: 1.8rem;
            color: var(--primary-blue);
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--accent-blue);
        }

        /* About Page Specific Styles */
        
        /* Hero Section */
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
            text-align: center;
            margin-bottom: 40px;
            border-radius: 10px;
        }

        .hero-content h1 {
            font-size: 2.8rem;
            margin-bottom: 20px;
            color: white;
        }

        .hero-content p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto 30px;
            color: rgba(255, 255, 255, 0.9);
        }

        /* Mission & Vision */
        .mission-vision {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
            margin-bottom: 40px;
        }

        .mission-card, .vision-card {
            background-color: var(--white);
            padding: 30px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            text-align: center;
            transition: var(--transition);
        }

        .mission-card:hover, .vision-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .mission-card {
            border-top: 4px solid var(--success-green);
        }

        .vision-card {
            border-top: 4px solid var(--accent-blue);
        }

        .mission-icon, .vision-icon {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--primary-blue);
        }

        .mission-icon {
            color: var(--success-green);
        }

        .vision-icon {
            color: var(--accent-blue);
        }

        /* Company Info */
        .company-info {
            background-color: var(--white);
            padding: 40px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            margin-bottom: 40px;
        }

        .company-info p {
            margin-bottom: 20px;
            font-size: 1.1rem;
            line-height: 1.8;
        }

        /* Values Section */
        .values-section {
            margin-bottom: 40px;
        }

        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
        }

        .value-card {
            background-color: var(--white);
            padding: 30px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            text-align: center;
            transition: var(--transition);
            border-top: 4px solid var(--accent-blue);
        }

        .value-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .value-icon {
            font-size: 2.5rem;
            color: var(--accent-blue);
            margin-bottom: 20px;
        }

        /* Certifications */
        .certifications {
            margin-bottom: 40px;
        }

        .cert-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .cert-card {
            background-color: var(--white);
            padding: 25px;
            border-radius: 10px;
            box-shadow: var(--shadow);
            text-align: center;
            transition: var(--transition);
        }

        .cert-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .cert-icon {
            font-size: 2.5rem;
            color: var(--success-green);
            margin-bottom: 15px;
        }

        /* Team Section */
        .team-section {
            margin-bottom: 40px;
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .team-card {
            background-color: var(--white);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .team-img {
            height: 200px;
            background-color: #e9f7fe;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-blue);
            font-size: 4rem;
        }

        .team-info {
            padding: 25px;
        }

        .team-info h3 {
            font-size: 1.4rem;
            color: var(--primary-blue);
            margin-bottom: 5px;
        }

        .team-info .position {
            color: var(--medium-gray);
            font-weight: 500;
            margin-bottom: 15px;
            font-size: 0.9rem;
        }

        /* Timeline */
        .timeline-section {
            margin-bottom: 40px;
        }

        .timeline {
            position: relative;
            max-width: 800px;
            margin: 0 auto;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 2px;
            height: 100%;
            background-color: var(--accent-blue);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 40px;
            width: 50%;
            padding: 20px;
        }

        .timeline-item:nth-child(odd) {
            left: 0;
            padding-right: 40px;
            text-align: right;
        }

        .timeline-item:nth-child(even) {
            left: 50%;
            padding-left: 40px;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            top: 20px;
            width: 20px;
            height: 20px;
            background-color: var(--white);
            border: 3px solid var(--accent-blue);
            border-radius: 50%;
        }

        .timeline-item:nth-child(odd)::before {
            right: -10px;
        }

        .timeline-item:nth-child(even)::before {
            left: -10px;
        }

        .timeline-year {
            font-weight: 700;
            color: var(--primary-blue);
            margin-bottom: 10px;
        }

        .timeline-content {
            background-color: var(--white);
            padding: 20px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        /* Contact CTA */
        .contact-cta {
            background: linear-gradient(135deg, var(--primary-blue), var(--accent-blue));
            color: white;
            padding: 50px 40px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 40px;
        }

        .contact-cta h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: white;
        }

        .contact-cta p {
            font-size: 1.1rem;
            margin-bottom: 30px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            opacity: 0.9;
        }

        .cta-button {
            display: inline-block;
            background-color: white;
            color: var(--primary-blue);
            padding: 15px 40px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            font-size: 1.1rem;
        }

        .cta-button:hover {
            background-color: var(--light-blue);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Footer - EXACTLY SAME AS OTHER PAGES */
        footer {
            background-color: #2c3e50;
            color: var(--white);
            padding: 60px 0 30px;
            margin-top: 40px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            margin-bottom: 50px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 25px;
            color: var(--light-blue);
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3:after {
            content: '';
            position: absolute;
            width: 40px;
            height: 2px;
            background-color: var(--accent-blue);
            bottom: 0;
            left: 0;
        }

        .footer-column p, .footer-column a {
            color: #bdc3c7;
            margin-bottom: 15px;
            display: block;
            text-decoration: none;
            transition: var(--transition);
        }

        .footer-column a:hover {
            color: var(--light-blue);
            padding-left: 5px;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .contact-item i {
            color: var(--accent-blue);
            width: 20px;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: var(--white);
            text-decoration: none;
            transition: var(--transition);
        }

        .social-icon:hover {
            background-color: var(--accent-blue);
            transform: translateY(-5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #95a5a6;
            font-size: 0.9rem;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .page-title {
                font-size: 2.2rem;
            }
            
            .mission-vision {
                grid-template-columns: 1fr;
            }
            
            .hero-content h1 {
                font-size: 2.2rem;
            }
            
            .footer-content {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .timeline::before {
                left: 30px;
            }
            
            .timeline-item {
                width: 100%;
                left: 0 !important;
                padding-left: 70px !important;
                padding-right: 20px !important;
                text-align: left !important;
            }
            
            .timeline-item::before {
                left: 20px !important;
            }
        }

        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }
            
            .nav-menu {
                position: fixed;
                top: 80px;
                left: 0;
                width: 100%;
                background-color: var(--white);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
                transform: translateY(-150%);
                transition: transform 0.5s ease;
                z-index: 999;
            }
            
            .nav-menu.active {
                transform: translateY(0);
            }
            
            .nav-menu li {
                margin: 0 0 20px 0;
            }
            
            .page-title {
                font-size: 1.8rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .hero-content h1 {
                font-size: 1.8rem;
            }
            
            .hero-content p {
                font-size: 1rem;
            }
            
            .contact-cta h2 {
                font-size: 1.6rem;
            }
            
            .footer-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }
        }

        @media (max-width: 576px) {
            .page-title {
                font-size: 1.6rem;
            }
            
            .hero-section {
                padding: 50px 0;
            }
            
            .company-info {
                padding: 25px;
            }
            
            .contact-cta {
                padding: 40px 25px;
            }
            
            .cta-button {
                padding: 12px 30px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header & Navigation  -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-bolt logo-icon"></i>
                    <span class="logo-text">SRS Electrical</span>
                </a>
                
                <div class="mobile-toggle" id="mobileToggle">
                    <i class="fas fa-bars"></i>
                </div>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php" class="active">About</a></li>
                    <li class="dropdown">
                        <a href="lab-testing.php">Lab Testing <i class="fas fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                            <a href="report.php">Reports</a>
                            <a href="cpri.php">CPRI Testing</a>
                        </div>
                    </li>
                    <li><a href="product.php">Product Catalog</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Page Header  -->
    <header class="page-header">
        <div class="container">
            <h1 class="page-title">About SRS Electrical</h1>
            <p class="page-subtitle">Pioneering Excellence in Electrical Testing and Lab Automation Since 2005</p>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="hero-content">
                <h1>Leading the Future of Electrical Testing</h1>
                <p>With over 18 years of excellence, SRS Electrical Appliances has established itself as a trusted name in electrical testing, lab automation, and CPRI-approved certification services. We combine cutting-edge technology with expert knowledge to deliver reliable solutions.</p>
            </div>
        </section>

        <!-- Company Information -->
        <section>
            <h2 class="section-title">Our Story</h2>
            <div class="company-info">
                <p>Founded in 2005 by electrical engineering pioneers, SRS Electrical Appliances began as a small testing facility in Bengaluru. Today, we have evolved into a state-of-the-art laboratory with national recognition for our testing capabilities and automation solutions.</p>
                
                <p>Our journey started with a simple mission: to provide accurate, reliable, and timely electrical testing services to the growing industrial sector. Over the years, we have invested in advanced testing equipment, trained certified technicians, and developed proprietary automation systems that have set new industry standards.</p>
                
                <p>With a team of over 50 engineers, technicians, and quality assurance professionals, we have successfully tested more than 50,000 electrical products across various categories including switchgear, control panels, capacitors, and specialized electrical equipment.</p>
                
                <p>Our commitment to quality has earned us recognition from CPRI (Central Power Research Institute) and ISO 9001:2015 certification, making us a preferred testing partner for leading electrical manufacturers across India.</p>
            </div>
        </section>

        <!-- Mission & Vision -->
        <section>
            <h2 class="section-title">Our Mission & Vision</h2>
            <div class="mission-vision">
                <div class="mission-card">
                    <div class="mission-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Our Mission</h3>
                    <p>To provide accurate, reliable, and efficient electrical testing solutions through advanced lab automation, ensuring safety, compliance, and quality for all electrical products while maintaining the highest standards of technical excellence and customer service.</p>
                </div>
                
                <div class="vision-card">
                    <div class="vision-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3>Our Vision</h3>
                    <p>To become India's premier electrical testing and certification facility, recognized globally for innovation in lab automation, setting industry benchmarks for accuracy and reliability in electrical safety testing and compliance certification.</p>
                </div>
            </div>
        </section>

        <!-- Company Values -->
        <section class="values-section">
            <h2 class="section-title">Our Core Values</h2>
            <div class="values-grid">
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Safety First</h3>
                    <p>Ensuring the highest safety standards in all testing procedures and products we certify.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-certificate"></i>
                    </div>
                    <h3>Quality Excellence</h3>
                    <p>Maintaining uncompromising quality in testing accuracy and certification processes.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3>Innovation</h3>
                    <p>Continuously upgrading our technology and methods to stay at the forefront of electrical testing.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Customer Trust</h3>
                    <p>Building lasting relationships through transparency, reliability, and exceptional service.</p>
                </div>
            </div>
        </section>

        <!-- Certifications -->
        <section class="certifications">
            <h2 class="section-title">Accreditations & Certifications</h2>
            <div class="cert-grid">
                <div class="cert-card">
                    <div class="cert-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <h3>ISO 9001:2015</h3>
                    <p>Quality Management System Certified</p>
                </div>
                
                <div class="cert-card">
                    <div class="cert-icon">
                        <i class="fas fa-certificate"></i>
                    </div>
                    <h3>CPRI Approved</h3>
                    <p>Central Power Research Institute Recognition</p>
                </div>
                
                <div class="cert-card">
                    <div class="cert-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <h3>NABL Recognition</h3>
                    <p>National Accreditation Board for Testing</p>
                </div>
                
                <div class="cert-card">
                    <div class="cert-icon">
                        <i class="fas fa-industry"></i>
                    </div>
                    <h3>BIS Approved</h3>
                    <p>Bureau of Indian Standards Compliance</p>
                </div>
            </div>
        </section>

        <!-- Company Timeline -->
        <section class="timeline-section">
            <h2 class="section-title">Our Journey</h2>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-year">2005</div>
                    <div class="timeline-content">
                        <h3>Company Foundation</h3>
                        <p>SRS Electrical Appliances founded in Bengaluru with basic electrical testing facilities.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-year">2010</div>
                    <div class="timeline-content">
                        <h3>First CPRI Approval</h3>
                        <p>Received CPRI recognition for switchgear and transformer testing capabilities.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-year">2015</div>
                    <div class="timeline-content">
                        <h3>ISO Certification & Expansion</h3>
                        <p>Achieved ISO 9001:2015 certification and expanded to new 10,000 sq.ft. facility.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-year">2018</div>
                    <div class="timeline-content">
                        <h3>Lab Automation Launch</h3>
                        <p>Introduced automated testing systems and digital reporting platform.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-year">2022</div>
                    <div class="timeline-content">
                        <h3>National Recognition</h3>
                        <p>Recognized as one of India's top 10 electrical testing facilities by EEMA.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-year">2023</div>
                    <div class="timeline-content">
                        <h3>Digital Dashboard Launch</h3>
                        <p>Launched real-time testing dashboard for clients to monitor progress online.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Leadership Team -->
        <section class="team-section">
            <h2 class="section-title">Leadership Team</h2>
            <div class="team-grid">
                <div class="team-card">
                    <div class="team-img">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="team-info">
                        <h3>Dr. Rajesh Sharma</h3>
                        <div class="position">Founder & CEO</div>
                        <p>PhD in Electrical Engineering with 25+ years experience in power systems and testing.</p>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-img">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div class="team-info">
                        <h3>Dr. Anil Verma</h3>
                        <div class="position">Chief Technical Officer</div>
                        <p>Specialized in high voltage testing and lab automation systems development.</p>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-img">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="team-info">
                        <h3>Priya Singh</h3>
                        <div class="position">Quality Assurance Director</div>
                        <p>Leading quality control and certification processes with 15 years experience.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact CTA -->
        <section class="contact-cta">
            <h2>Ready to Test Your Electrical Products?</h2>
            <p>Partner with India's trusted electrical testing laboratory. Get accurate testing, CPRI certification, and comprehensive reports for your products.</p>
            <a href="contact.php" class="cta-button">Contact Our Team</a>
        </section>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <!-- Column 1: Contact Info -->
                <div class="footer-column">
                    <h3>Contact Us</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+91 98765 43210</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>info@srselectrical.com</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>123 Industrial Area, Phase II<br>Bengaluru, Karnataka 560058</span>
                        </div>
                    </div>
                </div>
                
                <!-- Column 2: Quick Links -->
                <div class="footer-column">
                    <h3>Quick Links</h3>
                     <a href="about.php">About Us</a>
                    <a href="contact.php">Contact Us</a>
                    <a href="cpri.php">CPRI Certification</a>
                    <a href="faqs.php">FAQs</a>
                    <a href="report.php">Testing Reports</a>
                </div>
                
                <!-- Column 3: Social Media -->
                <div class="footer-column">
                    <h3>Connect With Us</h3>
                    <p>Follow us on social media for updates on electrical testing standards and industry news.</p>
                    
                    <div class="social-links">
                        <a href="https://www.facebook.com/" class="social-icon">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://pk.linkedin.com/" class="social-icon">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="https://www.whatsapp.com/" class="social-icon">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <a href="https://x.com/" class="social-icon">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2023 SRS Electrical Appliances. All Rights Reserved. | ISO 9001:2015 Certified | CPRI Approved Testing Facility</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile Navigation Toggle - EXACTLY SAME AS OTHER PAGES
        const mobileToggle = document.getElementById('mobileToggle');
        const navMenu = document.getElementById('navMenu');
        
        mobileToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            mobileToggle.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Close mobile menu when clicking on a link - EXACTLY SAME AS OTHER PAGES
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });
        
        // Update year in footer - Same as other pages
        document.addEventListener('DOMContentLoaded', function() {
            const currentYear = new Date().getFullYear();
            const yearElement = document.querySelector('.footer-bottom p');
            yearElement.innerHTML = yearElement.innerHTML.replace('2023', currentYear);
        });
    </script>
</body>
</html>