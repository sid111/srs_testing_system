<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | SRS Electrical Appliances</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Base Styles and Reset - EXACTLY SAME AS OTHER PAGES */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary-blue: #1a5f7a;
            --accent-blue: #2a86ba;
            --light-blue: #57c5e6;
            --dark-gray: #333;
            --medium-gray: #666;
            --light-gray: #f8f9fa;
            --white: #ffffff;
            --border-color: #e0e0e0;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease;
            --success-green: #28a745;
            --danger-red: #dc3545;
        }

        body {
            line-height: 1.6;
            color: var(--dark-gray);
            background-color: var(--light-gray);
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        section {
            padding: 40px 0;
        }

        /* Navbar Styles - EXACTLY SAME AS OTHER PAGES */
        header {
            background-color: var(--white);
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logo-icon {
            color: var(--primary-blue);
            font-size: 2rem;
            margin-right: 10px;
        }

        .logo-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-blue);
        }

        .nav-menu {
            display: flex;
            list-style: none;
        }

        .nav-menu li {
            position: relative;
            margin-left: 30px;
        }

        .nav-menu a {
            text-decoration: none;
            color: var(--dark-gray);
            font-weight: 600;
            transition: var(--transition);
            padding: 5px 0;
            position: relative;
        }

        .nav-menu a:hover {
            color: var(--primary-blue);
        }

        .nav-menu a.active {
            color: var(--primary-blue);
        }

        .nav-menu a.active:after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            background: var(--primary-blue);
            left: 0;
            bottom: 0;
        }

        .nav-menu a:after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary-blue);
            left: 0;
            bottom: 0;
            transition: var(--transition);
        }

        .nav-menu a:hover:after {
            width: 100%;
        }

        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: var(--white);
            min-width: 200px;
            box-shadow: var(--shadow);
            border-radius: 4px;
            z-index: 1;
            top: 100%;
            left: 0;
            padding: 10px 0;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a {
            display: block;
            padding: 10px 20px;
            color: var(--dark-gray);
        }

        .dropdown-content a:hover {
            background-color: var(--light-gray);
        }

        .dashboard-btn {
            background-color: var(--accent-blue);
            color: white;
            padding: 10px 25px;
            border-radius: 4px;
        }

        .dashboard-btn:hover {
            background-color: var(--primary-blue);
            transform: translateY(-3px);
        }

        .mobile-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary-blue);
        }

        /* Page Header - EXACTLY SAME AS OTHER PAGES */
        .page-header {
            background-color: var(--white);
            padding: 30px 0;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 30px;
            position: relative;
            top: auto;
             z-index: 900;
        }

        .page-title {
            font-size: 2.5rem;
            color: var(--primary-blue);
            font-weight: 700;
            text-align: center;
        }

        .page-subtitle {
            text-align: center;
            color: var(--medium-gray);
            margin-top: 10px;
            font-size: 1.1rem;
        }

        /* Section Titles - EXACTLY SAME AS OTHER PAGES */
        .section-title {
            font-size: 1.8rem;
            color: var(--primary-blue);
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--accent-blue);
        }

        /* Contact Page Layout */
        .contact-layout {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 40px;
        }

        /* Contact Information */
        .contact-info {
            background-color: var(--white);
            padding: 30px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .contact-details {
            margin-top: 20px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
            padding-bottom: 25px;
            border-bottom: 1px solid var(--border-color);
        }

        .contact-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .contact-icon {
            width: 50px;
            height: 50px;
            background-color: rgba(42, 134, 186, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            flex-shrink: 0;
            color: var(--accent-blue);
            font-size: 1.2rem;
        }

        .contact-content h3 {
            font-size: 1.2rem;
            color: var(--primary-blue);
            margin-bottom: 8px;
        }

        .contact-content p {
            color: var(--medium-gray);
            line-height: 1.6;
        }

        .social-contact {
            margin-top: 30px;
        }

        .social-icons {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }

        .social-icon-contact {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 45px;
            height: 45px;
            background-color: rgba(42, 134, 186, 0.1);
            border-radius: 50%;
            color: var(--accent-blue);
            text-decoration: none;
            transition: var(--transition);
            font-size: 1.2rem;
        }

        .social-icon-contact:hover {
            background-color: var(--accent-blue);
            color: white;
            transform: translateY(-3px);
        }

        /* Contact Form */
        .contact-form-container {
            background-color: var(--white);
            padding: 30px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark-gray);
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(42, 134, 186, 0.1);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 1rem;
            background-color: white;
            cursor: pointer;
        }

        .form-select:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(42, 134, 186, 0.1);
        }

        .submit-btn {
            background-color: var(--accent-blue);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            margin-top: 10px;
        }

        .submit-btn:hover {
            background-color: var(--primary-blue);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(42, 134, 186, 0.3);
        }

        /* Map Section */
        .map-section {
            margin-bottom: 40px;
        }

        .map-container {
            background-color: var(--white);
            padding: 30px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .map-placeholder {
            height: 400px;
            background-color: #f8f9fa;
            border-radius: 6px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: var(--medium-gray);
            position: relative;
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        .map-placeholder i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
            z-index: 1;
        }

        .map-placeholder::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(42, 134, 186, 0.05) 50%, transparent 70%);
            animation: shimmer 2s infinite linear;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .map-details {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }

        .map-detail-item {
            text-align: center;
            padding: 15px;
            background-color: rgba(42, 134, 186, 0.05);
            border-radius: 6px;
        }

        .map-detail-icon {
            font-size: 1.5rem;
            color: var(--accent-blue);
            margin-bottom: 10px;
        }

        /* Business Hours */
        .hours-section {
            margin-bottom: 40px;
        }

        .hours-container {
            background-color: var(--white);
            padding: 30px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .hours-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .hours-table tr {
            border-bottom: 1px solid var(--border-color);
        }

        .hours-table tr:last-child {
            border-bottom: none;
        }

        .hours-table td {
            padding: 15px 0;
            color: var(--medium-gray);
        }

        .hours-table td:first-child {
            font-weight: 600;
            color: var(--dark-gray);
            width: 150px;
        }

        .hours-note {
            margin-top: 20px;
            padding: 15px;
            background-color: rgba(40, 167, 69, 0.1);
            border-radius: 6px;
            color: var(--success-green);
            font-size: 0.9rem;
        }

        /* Footer - EXACTLY SAME AS OTHER PAGES */
        footer {
            background-color: #2c3e50;
            color: var(--white);
            padding: 60px 0 30px;
            margin-top: 40px;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            margin-bottom: 50px;
        }

        .footer-column h3 {
            font-size: 1.3rem;
            margin-bottom: 25px;
            color: var(--light-blue);
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3:after {
            content: '';
            position: absolute;
            width: 40px;
            height: 2px;
            background-color: var(--accent-blue);
            bottom: 0;
            left: 0;
        }

        .footer-column p, .footer-column a {
            color: #bdc3c7;
            margin-bottom: 15px;
            display: block;
            text-decoration: none;
            transition: var(--transition);
        }

        .footer-column a:hover {
            color: var(--light-blue);
            padding-left: 5px;
        }

        .contact-info-footer {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .contact-item-footer {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .contact-item-footer i {
            color: var(--accent-blue);
            width: 20px;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .social-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: var(--white);
            text-decoration: none;
            transition: var(--transition);
        }

        .social-icon:hover {
            background-color: var(--accent-blue);
            transform: translateY(-5px);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #95a5a6;
            font-size: 0.9rem;
        }

        /* Notification */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 2000;
            animation: slideIn 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            display: none;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .notification-success {
            background-color: var(--success-green);
        }

        .notification-error {
            background-color: var(--danger-red);
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .page-title {
                font-size: 2.2rem;
            }
            
            .contact-layout {
                grid-template-columns: 1fr;
                gap: 30px;
            }
            
            .map-details {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .footer-content {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }
            
            .nav-menu {
                position: fixed;
                top: 80px;
                left: 0;
                width: 100%;
                background-color: var(--white);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
                transform: translateY(-150%);
                transition: transform 0.5s ease;
                z-index: 999;
            }
            
            .nav-menu.active {
                transform: translateY(0);
            }
            
            .nav-menu li {
                margin: 0 0 20px 0;
            }
            
            .page-title {
                font-size: 1.8rem;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .map-details {
                grid-template-columns: 1fr;
            }
            
            .footer-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }
        }

        @media (max-width: 576px) {
            .page-title {
                font-size: 1.6rem;
            }
            
            .contact-info, .contact-form-container, .map-container, .hours-container {
                padding: 20px;
            }
            
            .contact-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .contact-icon {
                margin-bottom: 10px;
            }
            
            .map-placeholder {
                height: 300px;
            }
            
            .notification {
                left: 20px;
                right: 20px;
                top: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Header & Navigation  -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-bolt logo-icon"></i>
                    <span class="logo-text">SRS Electrical</span>
                </a>
                
                <div class="mobile-toggle" id="mobileToggle">
                    <i class="fas fa-bars"></i>
                </div>
                
                <ul class="nav-menu" id="navMenu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li class="dropdown">
                        <a href="lab-testing.php">Lab Testing <i class="fas fa-chevron-down"></i></a>
                        <div class="dropdown-content">
                          
                            <a href="report.php">Reports</a>
                            <a href="cpri.php">CPRI Testing</a>
                        </div>
                    </li>
                    <li><a href="product.php">Product Catalog</a></li>
                    <li><a href="contact.php" class="active">Contact Us</a></li>
                    
                </ul>
            </nav>
        </div>
    </header>

    <!-- Page Header  -->
    <header class="page-header">
        <div class="container">
            <h1 class="page-title">Contact Us</h1>
            <p class="page-subtitle">Get in touch with our electrical testing experts. We're here to help with all your testing needs.</p>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <!-- Contact Layout -->
        <section>
            <div class="contact-layout">
                <!-- Contact Information -->
                <div class="contact-info">
                    <h2 class="section-title">Get In Touch</h2>
                    <div class="contact-details">
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="contact-content">
                                <h3>Our Location</h3>
                                <p>123 Industrial Area, Phase II<br>
                                   Bengaluru, Karnataka 560058<br>
                                   India</p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="contact-content">
                                <h3>Phone Numbers</h3>
                                <p>Main Office: +91 98765 43210<br>
                                   Testing Lab: +91 98765 43211<br>
                                   Support: +91 98765 43212</p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="contact-content">
                                <h3>Email Addresses</h3>
                                <p>General Inquiries: info@srselectrical.com<br>
                                   Testing Services: testing@srselectrical.com<br>
                                   Support: support@srselectrical.com</p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="contact-content">
                                <h3>Business Hours</h3>
                                <p>Monday - Friday: 9:00 AM - 6:00 PM<br>
                                   Saturday: 9:00 AM - 2:00 PM<br>
                                   Sunday: Closed</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="social-contact">
                        <h3 style="color: var(--primary-blue); margin-bottom: 15px;">Follow Us</h3>
                        <div class="social-icons">
                            <a href="https://www.facebook.com/" class="social-icon-contact">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.linkedin.com/" class="social-icon-contact">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="https://x.com/" class="social-icon-contact">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="https://www.instagram.com/" class="social-icon-contact">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div class="contact-form-container">
                    <h2 class="section-title">Send Message</h2>
                    <form id="contactForm">
                        <div class="form-group">
                            <label class="form-label" for="name">Full Name *</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter your full name" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="email">Email Address *</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter your email address" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="phone">Contact Number *</label>
                            <input type="tel" class="form-control" id="phone" placeholder="Enter your phone number" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="company">Company Name</label>
                            <input type="text" class="form-control" id="company" placeholder="Enter your company name">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="address">Address</label>
                            <textarea class="form-control" id="address" placeholder="Enter your complete address"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="service">Service Required</label>
                            <select class="form-select" id="service">
                                <option value="">Select a service</option>
                                <option value="lab-testing">Lab Testing</option>
                                <option value="cpri-testing">CPRI Testing</option>
                                <option value="product-certification">Product Certification</option>
                                <option value="automation">Automation Services</option>
                                <option value="consultation">Technical Consultation</option>
                                <option value="other">Other Services</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="message">Message *</label>
                            <textarea class="form-control" id="message" placeholder="Enter your message" required></textarea>
                        </div>
                        
                        <button type="submit" class="submit-btn">
                            <i class="fas fa-paper-plane"></i> Send Message
                        </button>
                    </form>
                </div>
            </div>
        </section>

        <!-- Map Section -->
        <section class="map-section">
            <h2 class="section-title">Find Our Location</h2>
            <div class="map-container">
                <div class="map-placeholder">
                    <i class="fas fa-map-marked-alt"></i>
                    <p>Interactive Map Location</p>
                    <small style="margin-top: 5px;">Bengaluru, Karnataka, India</small>
                </div>
                
                <div class="map-details">
                    <div class="map-detail-item">
                        <div class="map-detail-icon">
                            <i class="fas fa-subway"></i>
                        </div>
                        <h4>Nearest Metro</h4>
                        <p>Peenya Industrial Metro Station (1.2 km)</p>
                    </div>
                    
                    <div class="map-detail-item">
                        <div class="map-detail-icon">
                            <i class="fas fa-bus"></i>
                        </div>
                        <h4>Bus Station</h4>
                        <p>Peenya 2nd Stage Bus Stop (500 m)</p>
                    </div>
                    
                    <div class="map-detail-item">
                        <div class="map-detail-icon">
                            <i class="fas fa-car"></i>
                        </div>
                        <h4>Parking</h4>
                        <p>Ample parking space available for visitors</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Business Hours -->
        <section class="hours-section">
            <h2 class="section-title">Testing Lab Hours</h2>
            <div class="hours-container">
                <p style="margin-bottom: 20px; color: var(--medium-gray);">Our testing laboratory operates on a schedule to ensure quality service. Please note the following hours for different services:</p>
                
                <table class="hours-table">
                    <tr>
                        <td>General Testing</td>
                        <td>Monday - Friday: 9:00 AM - 6:00 PM</td>
                    </tr>
                    <tr>
                        <td>High Voltage Testing</td>
                        <td>Monday - Thursday: 10:00 AM - 4:00 PM</td>
                    </tr>
                    <tr>
                        <td>CPRI Testing</td>
                        <td>Tuesday & Thursday: 9:00 AM - 5:00 PM</td>
                    </tr>
                    <tr>
                        <td>Automation Services</td>
                        <td>Monday - Friday: 10:00 AM - 5:00 PM</td>
                    </tr>
                    <tr>
                        <td>Sample Drop-off</td>
                        <td>Monday - Saturday: 8:00 AM - 6:00 PM</td>
                    </tr>
                    <tr>
                        <td>Report Collection</td>
                        <td>Monday - Friday: 2:00 PM - 5:00 PM</td>
                    </tr>
                </table>
                
                <div class="hours-note">
                    <i class="fas fa-info-circle"></i> For emergency testing services outside business hours, please contact us via phone for special arrangements.
                </div>
            </div>
        </section>
    </div>

    <!-- Notification -->
    <div id="notification" class="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notificationText">Message sent successfully!</span>
    </div>

    <!-- Footer  -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <!-- Column 1: Contact Info -->
                <div class="footer-column">
                    <h3>Contact Us</h3>
                    <div class="contact-info-footer">
                        <div class="contact-item-footer">
                            <i class="fas fa-phone"></i>
                            <span>+91 98765 43210</span>
                        </div>
                        <div class="contact-item-footer">
                            <i class="fas fa-envelope"></i>
                            <span>info@srselectrical.com</span>
                        </div>
                        <div class="contact-item-footer">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>123 Industrial Area, Phase II<br>Bengaluru, Karnataka 560058</span>
                        </div>
                    </div>
                </div>
                
                <!-- Column 2: Quick Links -->
                <div class="footer-column">
                    <h3>Quick Links</h3>
                     <a href="about.php">About Us</a>
                    <a href="contact.php">Contact Us</a>
                    <a href="cpri.php">CPRI Certification</a>
                    <a href="faqs.php">FAQs</a>
                    <a href="report.php">Testing Reports</a>
                </div>
                
                <!-- Column 3: Social Media -->
                <div class="footer-column">
                    <h3>Connect With Us</h3>
                    <p>Follow us on social media for updates on electrical testing standards and industry news.</p>
                    
                    <div class="social-links">
                        <a href="https://www.facebook.com/" class="social-icon">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://pk.linkedin.com/" class="social-icon">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="https://www.whatsapp.com/" class="social-icon">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                        <a href="https://x.com/" class="social-icon">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2023 SRS Electrical Appliances. All Rights Reserved. | ISO 9001:2015 Certified | CPRI Approved Testing Facility</p>
            </div>
        </div>
    </footer>

    <script>
        // Mobile Navigation Toggle - 
        const mobileToggle = document.getElementById('mobileToggle');
        const navMenu = document.getElementById('navMenu');
        
        mobileToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            mobileToggle.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Close mobile menu when clicking on a link 
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });
        
        // Contact Form Submission
        const contactForm = document.getElementById('contactForm');
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notificationText');
        
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const company = document.getElementById('company').value;
            const address = document.getElementById('address').value;
            const service = document.getElementById('service').value;
            const message = document.getElementById('message').value;
            
            // Basic validation
            if (!name || !email || !phone || !message) {
                showNotification('Please fill in all required fields', false);
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showNotification('Please enter a valid email address', false);
                return;
            }
            
            // Phone validation (basic)
            const phoneRegex = /^[0-9\-\+\s\(\)]{10,}$/;
            if (!phoneRegex.test(phone.replace(/\D/g, ''))) {
                showNotification('Please enter a valid phone number', false);
                return;
            }
            
            // Simulate form submission
            showNotification('Sending your message...', true);
            
            // In a real application, you would send data to server here
            setTimeout(() => {
                // Show success message
                showNotification('Message sent successfully! We will contact you soon.', true);
                
                // Reset form
                contactForm.reset();
                
                // Log form data (in real app, this would be sent to server)
                console.log('Contact Form Submitted:', {
                    name,
                    email,
                    phone,
                    company,
                    address,
                    service,
                    message,
                    timestamp: new Date().toISOString()
                });
            }, 1500);
        });
        
        // Show notification function
        function showNotification(message, isSuccess = true) {
            notificationText.textContent = message;
            notification.className = `notification ${isSuccess ? 'notification-success' : 'notification-error'}`;
            notification.style.display = 'flex';
            
            // Update icon
            const icon = notification.querySelector('i');
            icon.className = isSuccess ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
            
            // Hide after 4 seconds
            setTimeout(() => {
                notification.style.display = 'none';
            }, 4000);
        }
        
        // Update year in footer - Same as other pages
        document.addEventListener('DOMContentLoaded', function() {
            const currentYear = new Date().getFullYear();
            const yearElement = document.querySelector('.footer-bottom p');
            yearElement.innerHTML = yearElement.innerHTML.replace('2023', currentYear);
            
            // Add animation to map placeholder
            const mapPlaceholder = document.querySelector('.map-placeholder');
            setInterval(() => {
                mapPlaceholder.style.animation = 'none';
                setTimeout(() => {
                    mapPlaceholder.style.animation = 'none';
                }, 10);
            }, 5000);
        });
    </script>
</body>
</html>